package mylib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Tiện ích kết nối CSDL SQL Server.
 *
 * Sửa lỗi so với file gốc:
 *   DB_NAME: "CarWashDB" → "AutoWashPro" (khớp tên database thực tế trong context.xml)
 *
 * LƯU Ý BẢO MẬT: không hardcode password trong code thực tế.
 * Hãy đưa vào file cấu hình bên ngoài hoặc biến môi trường trước khi nộp bài thật.
 */
public class DBUtils {

    private static final String DB_NAME     = "AutoWashPro";
    private static final String DB_USER     = "SA";
    private static final String DB_PASSWORD = "12345";

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://localhost:1433;databaseName=" + DB_NAME;
        return DriverManager.getConnection(url, DB_USER, DB_PASSWORD);
    }
}
