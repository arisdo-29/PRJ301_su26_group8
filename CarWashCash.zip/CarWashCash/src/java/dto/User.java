package dto;

import java.sql.Date;

/**
 * DTO ánh xạ bảng [dbo].[users]
 * Gộp từ: dto/User.java + dto/User-d.java
 *
 * Tên biến chuẩn hoá theo cột DB:
 *   id, loginId, password, role, fullName, email, isActive, createAt
 */
public class User {

    private int    id;
    private String loginId;   // phone hoặc username (dùng cho login)
    private String password;
    private String role;      // "admin", "customer", ...
    private String fullName;
    private String email;
    private boolean isActive;
    private Date   createAt;

    // ── Constructors ────────────────────────────────────────────

    public User() {}

    /** Constructor đầy đủ (dùng khi đọc từ DB) */
    public User(int id, String loginId, String password, String role,
                String fullName, String email, boolean isActive, Date createAt) {
        this.id       = id;
        this.loginId  = loginId;
        this.password = password;
        this.role     = role;
        this.fullName = fullName;
        this.email    = email;
        this.isActive = isActive;
        this.createAt = createAt;
    }

    /** Constructor không có id (dùng khi tạo user mới chưa có ID từ DB) */
    public User(String loginId, String password, String role,
                String fullName, String email, boolean isActive, Date createAt) {
        this.loginId  = loginId;
        this.password = password;
        this.role     = role;
        this.fullName = fullName;
        this.email    = email;
        this.isActive = isActive;
        this.createAt = createAt;
    }

    // ── Getters & Setters ───────────────────────────────────────

    public int getId()                  { return id; }
    public void setId(int id)           { this.id = id; }

    public String getLoginId()          { return loginId; }
    public void setLoginId(String v)    { this.loginId = v; }

    public String getPassword()         { return password; }
    public void setPassword(String v)   { this.password = v; }

    public String getRole()             { return role; }
    public void setRole(String v)       { this.role = v; }

    public String getFullName()         { return fullName; }
    public void setFullName(String v)   { this.fullName = v; }

    public String getEmail()            { return email; }
    public void setEmail(String v)      { this.email = v; }

    public boolean isIsActive()         { return isActive; }
    public void setIsActive(boolean v)  { this.isActive = v; }

    public Date getCreateAt()           { return createAt; }
    public void setCreateAt(Date v)     { this.createAt = v; }
}
