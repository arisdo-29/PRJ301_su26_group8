package dao;

import dto.User;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import mylib.DBUtils;

/**
 * DAO cho bảng [dbo].[users]
 * Gộp từ: dao/UserDAO.java + dao/UserDAO-d.java
 *
 * Phương thức:
 *   createNewUser(User)          — INSERT user mới
 *   getUser(String, String)      — lấy user theo email + password (login)
 *   getUser(String)              — lấy user theo email (kiểm tra trùng khi đăng ký)
 */
public class UserDAO {

    /**
     * Thêm user mới vào DB.
     * @return số dòng bị ảnh hưởng (1 = thành công, 0 = thất bại)
     */
    public int createNewUser(User u) {
        int result = 0;
        Connection cn = null;
        try {
            cn = DBUtils.getConnection();
            if (cn != null) {
                String sql = "INSERT INTO [dbo].[users] "
                           + "([login_id], [password], [full_name], [email], [is_active], [created_at]) "
                           + "VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement st = cn.prepareStatement(sql);
                st.setString(1, u.getLoginId());
                st.setString(2, u.getPassword());
                st.setString(3, u.getFullName());
                st.setString(4, u.getEmail());
                st.setBoolean(5, u.isIsActive());
                st.setDate(6, u.getCreateAt());
                result = st.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (cn != null) cn.close(); } catch (Exception e) { e.printStackTrace(); }
        }
        return result;
    }

    /**
     * Lấy user theo email và password — dùng cho chức năng đăng nhập.
     * Lưu ý: nên hash password trước khi so sánh (cải tiến sau).
     * @return User nếu tìm thấy, null nếu không khớp
     */
    public User getUser(String email, String password) {
        User result = null;
        Connection cn = null;
        try {
            cn = DBUtils.getConnection();
            if (cn != null) {
                String sql = "SELECT [id], [login_id], [password], [role], [full_name], "
                           + "[email], [is_active], [created_at] "
                           + "FROM [dbo].[users] "
                           + "WHERE [email] = ? AND [password] = ?";
                PreparedStatement st = cn.prepareStatement(sql);
                st.setString(1, email);
                st.setString(2, password);
                ResultSet rs = st.executeQuery();
                if (rs.next()) {
                    result = mapRow(rs, email);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (cn != null) cn.close(); } catch (Exception e) { e.printStackTrace(); }
        }
        return result;
    }

    /**
     * Lấy user theo email — dùng để kiểm tra email đã tồn tại trước khi đăng ký.
     * @return User nếu tìm thấy, null nếu chưa có
     */
    public User getUser(String email) {
        User result = null;
        Connection cn = null;
        try {
            cn = DBUtils.getConnection();
            if (cn != null) {
                String sql = "SELECT [id], [login_id], [password], [role], [full_name], "
                           + "[email], [is_active], [created_at] "
                           + "FROM [dbo].[users] "
                           + "WHERE [email] = ?";
                PreparedStatement st = cn.prepareStatement(sql);
                st.setString(1, email);
                ResultSet rs = st.executeQuery();
                if (rs.next()) {
                    result = mapRow(rs, email);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try { if (cn != null) cn.close(); } catch (Exception e) { e.printStackTrace(); }
        }
        return result;
    }

    /**
     * Hàm helper: map một ResultSet row → User object.
     * Dùng chung cho cả 2 hàm getUser để tránh lặp code.
     */
    private User mapRow(ResultSet rs, String email) throws Exception {
        int     uid      = rs.getInt("id");
        String  loginId  = rs.getString("login_id");
        String  password = rs.getString("password");
        String  role     = rs.getString("role");
        String  fullName = rs.getString("full_name");
        boolean isActive = rs.getBoolean("is_active");
        Date    createAt = rs.getDate("created_at");
        return new User(uid, loginId, password, role, fullName, email, isActive, createAt);
    }
}
