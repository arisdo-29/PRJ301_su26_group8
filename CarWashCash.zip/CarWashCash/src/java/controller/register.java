package controller;

import dao.UserDAO;
import dto.User;
import java.io.IOException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "register", urlPatterns = {"/register"})
public class register extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // GET → chỉ hiển thị form đăng ký
        request.getRequestDispatcher("register_page.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String fullName = request.getParameter("txtfullName");
        String email    = request.getParameter("txtemail");
        String password = request.getParameter("txtpassword");

        UserDAO dao = new UserDAO();

        // Kiểm tra email đã tồn tại chưa
        User existing = dao.getUser(email);
        if (existing != null) {
            request.setAttribute("ERROR", "Email này đã được đăng ký. Vui lòng dùng email khác.");
            request.getRequestDispatcher("register_page.jsp").forward(request, response);
            return;
        }

        // Tạo user mới
        User newUser = new User();
        newUser.setLoginId(email);   // dùng email làm login_id
        newUser.setFullName(fullName);
        newUser.setEmail(email);
        newUser.setPassword(password);
        newUser.setRole("customer");
        newUser.setIsActive(true);
        newUser.setCreateAt(new Date(System.currentTimeMillis()));

        int rs = dao.createNewUser(newUser);
        if (rs >= 1) {
            response.sendRedirect("index.jsp");  // đăng ký thành công → về trang login
        } else {
            request.setAttribute("ERROR", "Đăng ký thất bại. Vui lòng thử lại.");
            request.getRequestDispatcher("register_page.jsp").forward(request, response);
        }
    }
}
