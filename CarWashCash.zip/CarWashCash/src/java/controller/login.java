package controller;

import dao.UserDAO;
import dto.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String email    = request.getParameter("txtemail");
            String password = request.getParameter("txtpassword");

            UserDAO dao = new UserDAO();
            User user   = dao.getUser(email, password);

            if (user == null) {
                request.setAttribute("ERROR", "Email hoặc mật khẩu không đúng.");
                request.getRequestDispatcher("login_page.jsp").forward(request, response);
            } else if (user.isIsActive()) {
                // Lưu user vào session — key "USER" dùng thống nhất toàn dự án
                request.getSession().setAttribute("USER", user);
                response.sendRedirect("dashboard");   // → MemberDashboard servlet
            } else {
                request.setAttribute("ERROR", "Tài khoản của bạn đã bị khoá.");
                request.getRequestDispatcher("login_page.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
