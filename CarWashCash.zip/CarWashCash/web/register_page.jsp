<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Đăng ký – AutoWash Pro</title>
  <style>
    body { margin:0; background:#F0F8FF; font-family:Inter,sans-serif; }
    .wrapper { min-height:100vh; display:flex; }
    .left { flex:1; background:#1A8FE3; color:white; padding:60px; }
    .left h1 { font-size:40px; margin-bottom:16px; }
    .benefit { margin-top:25px; padding-left:20px; }
    .benefit li { margin-bottom:15px; font-size:16px; }
    .illustration { font-size:140px; margin-top:50px; text-align:center; }
    .right { flex:1; display:flex; justify-content:center; align-items:center; }
    .card { width:500px; padding:40px; background:white; border:1px solid #C9DFF0; border-radius:12px; }
    .card h2 { margin-bottom:8px; color:#1A2B3C; }
    .card .subtitle { color:#718096; font-size:14px; margin-bottom:24px; }
    .form-group { margin-bottom:16px; }
    label { display:block; margin-bottom:6px; font-weight:600; font-size:14px; color:#1A2B3C; }
    input, select { width:100%; padding:11px 12px; border:1px solid #C9DFF0; border-radius:8px; font-size:14px; box-sizing:border-box; }
    input:focus, select:focus { outline:none; border-color:#2979C8; }
    .btn { width:100%; border:none; padding:14px; cursor:pointer; font-weight:700; font-size:16px; color:white; background:#1A8FE3; border-radius:50px; margin-top:4px; }
    .btn:hover { background:#1570C0; }
    .login-link { margin-top:18px; text-align:center; font-size:14px; color:#555; }
    .login-link a { color:#1A8FE3; font-weight:700; text-decoration:none; }
    .error-msg { background:#FEF2F2; border:1px solid #FECACA; color:#DC2626; padding:12px 16px; border-radius:8px; font-size:14px; margin-bottom:16px; }
    @media (max-width:900px) { .wrapper { flex-direction:column; } .left { display:none; } .card { width:90%; } }
  </style>
</head>
<body>
<div class="wrapper">

  <!-- LEFT SIDE -->
  <div class="left">
    <h1>AutoWash Pro</h1>
    <ul class="benefit">
      <li>✔ Đặt lịch rửa xe online dễ dàng</li>
      <li>✔ Lưu thông tin xe của bạn</li>
      <li>✔ Chương trình tích điểm thưởng</li>
      <li>✔ Dịch vụ nhanh chóng và an toàn</li>
    </ul>
    <div class="illustration">🚗</div>
  </div>

  <!-- RIGHT SIDE -->
  <div class="right">
    <div class="card">
      <h2>Tạo tài khoản</h2>
      <p class="subtitle">Đăng ký để bắt đầu sử dụng dịch vụ</p>

      <%-- Hiển thị lỗi từ servlet (ví dụ: email trùng) --%>
      <%
          String errorMsg = (String) request.getAttribute("ERROR");
          if (errorMsg != null) {
      %>
        <div class="error-msg">⚠️ <%= errorMsg %></div>
      <% } %>

      <form action="register" method="post" accept-charset="UTF-8">

        <div class="form-group">
          <label>Họ và tên</label>
          <input type="text" name="txtfullName" placeholder="Nguyễn Văn A" required>
        </div>

        <div class="form-group">
          <label>Email</label>
          <input type="email" name="txtemail" placeholder="email@example.com" required>
        </div>

        <div class="form-group">
          <label>Mật khẩu</label>
          <input type="password" name="txtpassword" placeholder="Nhập mật khẩu" required>
        </div>

        <div class="form-group">
          <label>Xác nhận mật khẩu</label>
          <input type="password" name="txtconfirmPassword" placeholder="Nhập lại mật khẩu" required>
        </div>

        <button class="btn" type="submit">Tạo tài khoản</button>
      </form>

      <div class="login-link">
        Đã có tài khoản? <a href="login_page.jsp">Đăng nhập</a>
      </div>
    </div>
  </div>

</div>
</body>
</html>
